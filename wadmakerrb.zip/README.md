# makewad-rb

Create a WAD2 texture file from a folder of PNGs. Written in ruby & tk.
Made with ruby due to it's multiplatform usage, this wad maker should work on any OS supporting ruby (which is most of them).

## Setup

### Installing dependencies

Open a terminal in the folder and run `bundle install` or open the install.bat as an Administrator

### Making a WAD

1. Open the makewad.rb file, make sure this opens with Ruby.
2. Select your texture folder, palette, and output wad.
A default palette, texture folder, and .wad file have been setup for you, you could also simply paste your textures in the textures folder
3. Press Make Wad

Enjoy 👽

![image](https://github.com/user-attachments/assets/a0f4802b-e750-4e7b-8372-3334f758ac02)
